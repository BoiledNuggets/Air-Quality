import { NextResponse } from "next/server"

const AQI_TOKEN = "e545c8fb12ee2e0c3a6c0c4e556d73c53c6ae708"

export async function GET() {
  try {
    // Use the bounds API to get all stations in Thailand
    const response = await fetch(`https://api.waqi.info/v2/map/bounds?latlng=5.5,97.3,20.5,105.6&token=${AQI_TOKEN}`, {
      headers: {
        "Content-Type": "application/json",
      },
      // Cache for 5 minutes
      next: { revalidate: 300 },
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()

    if (data.status !== "ok") {
      throw new Error("API returned error status")
    }

    // Transform the data to match our expected format
    const transformedStations = data.data
      .filter((station: any) => station.aqi !== "-" && station.aqi !== undefined) // Filter out stations with no AQI data
      .map((station: any) => ({
        aqi: Number.parseInt(station.aqi) || 0,
        dominentpol: "pm25", // Default since this API doesn't provide dominant pollutant
        city: {
          name: station.station.name,
          geo: [station.lat, station.lon],
        },
        time: {
          iso: station.station.time,
        },
        iaqi: {
          // This API doesn't provide detailed pollutant data, so we'll use defaults
          pm25: { v: Math.round(Number.parseInt(station.aqi) * 0.7) }, // Rough estimation
          t: { v: 28 }, // Default temperature
          h: { v: 65 }, // Default humidity
          w: { v: 5 }, // Default wind speed
          wd: { v: Math.floor(Math.random() * 360) }, // Random wind direction for demo
        },
        forecast: {
          daily: {
            pm25: [], // This API doesn't provide forecast data
            pm10: [],
            uvi: [],
          },
        },
        stationId: station.uid.toString(),
        stationName: station.station.name,
        coordinates: [station.lat, station.lon],
      }))

    console.log(`Successfully fetched ${transformedStations.length} stations from bounds API`)

    return NextResponse.json({
      status: "ok",
      stations: transformedStations,
      count: transformedStations.length,
      total_stations: data.data.length,
    })
  } catch (error) {
    console.error("Error fetching AQI data:", error)
    return NextResponse.json({ error: "Failed to fetch AQI data" }, { status: 500 })
  }
}
