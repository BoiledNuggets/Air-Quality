import { NextResponse } from "next/server"

const AQI_TOKEN = "e545c8fb12ee2e0c3a6c0c4e556d73c53c6ae708"

export async function GET(request: Request, { params }: { params: Promise<{ stationId: string }> }) {
  try {
    const { stationId } = await params

    // Fetch detailed station data including forecast
    const response = await fetch(`https://api.waqi.info/feed/@${stationId}/?token=${AQI_TOKEN}`, {
      headers: {
        "Content-Type": "application/json",
      },
      // Cache for 30 minutes since forecast data doesn't change frequently
      next: { revalidate: 1800 },
    })

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    const data = await response.json()

    if (data.status !== "ok") {
      throw new Error("API returned error status")
    }

    return NextResponse.json({
      status: "ok",
      forecast: data.data.forecast || null,
      stationName: data.data.city?.name || "Unknown Station",
    })
  } catch (error) {
    console.error("Error fetching forecast data:", error)
    return NextResponse.json(
      {
        error: "Failed to fetch forecast data",
        forecast: null,
      },
      { status: 500 },
    )
  }
}
