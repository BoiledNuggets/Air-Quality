"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { AQIBadge } from "./ui/aqi-badge"
import { Thermometer, Droplets, Wind, Clock, Activity, MapPin } from 'lucide-react'

interface StationData {
  aqi: number
  stationName: string
  time: { iso: string }
  iaqi: {
    pm25?: { v: number }
    pm10?: { v: number }
    t?: { v: number }
    h?: { v: number }
    w?: { v: number }
    wd?: { v: number }
  }
}

interface CurrentConditionsProps {
  station: StationData
}

const getAQIStatus = (aqi: number) => {
  if (aqi <= 50) return "Good"
  if (aqi <= 100) return "Moderate"
  if (aqi <= 150) return "Unhealthy for Sensitive Groups"
  if (aqi <= 200) return "Unhealthy"
  if (aqi <= 300) return "Very Unhealthy"
  return "Hazardous"
}

const getWindDirection = (degrees: number) => {
  const directions = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW']
  const index = Math.round(degrees / 22.5) % 16
  return directions[index]
}

const cleanStationName = (name: string) => name.split(",")[0].trim()

export function CurrentConditions({ station }: CurrentConditionsProps) {
  return (
    <Card className="glass-card animate-scale-in">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-primary" />
          Current Conditions
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* AQI Display */}
        <div className="text-center space-y-4">
          <div className="relative">
            <div className="w-24 h-24 mx-auto mb-4 relative">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 animate-pulse"></div>
              <div className="relative z-10 w-full h-full flex items-center justify-center">
                <AQIBadge aqi={station.aqi} size="lg" />
              </div>
            </div>
          </div>
          
          <div className="space-y-2">
            <h3 className="text-lg font-semibold">{getAQIStatus(station.aqi)}</h3>
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <MapPin className="w-4 h-4" />
              <span>{cleanStationName(station.stationName)}</span>
            </div>
          </div>
        </div>

        {/* Environmental Data */}
        <div className="space-y-4">
          <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
            Environmental Data
          </h4>
          
          <div className="grid grid-cols-2 gap-4">
            {station.iaqi.t && (
              <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                <div className="p-2 bg-red-100 dark:bg-red-900/20 rounded-lg">
                  <Thermometer className="w-4 h-4 text-red-600" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Temperature</p>
                  <p className="font-semibold">{station.iaqi.t.v}°C</p>
                </div>
              </div>
            )}

            {station.iaqi.h && (
              <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-lg">
                  <Droplets className="w-4 h-4 text-blue-600" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Humidity</p>
                  <p className="font-semibold">{station.iaqi.h.v}%</p>
                </div>
              </div>
            )}

            {station.iaqi.w && (
              <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg col-span-2">
                <div className="p-2 bg-gray-100 dark:bg-gray-800 rounded-lg">
                  <Wind className="w-4 h-4 text-gray-600" />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Wind</p>
                  <div className="flex items-center gap-2">
                    <p className="font-semibold">{station.iaqi.w.v} km/h</p>
                    {station.iaqi.wd && (
                      <>
                        <div
                          className="text-primary text-lg leading-none transition-transform duration-300"
                          style={{ transform: `rotate(${station.iaqi.wd.v}deg)` }}
                        >
                          ↑
                        </div>
                        <span className="text-xs font-medium text-muted-foreground">
                          {getWindDirection(station.iaqi.wd.v)}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Pollutant Levels */}
        <div className="space-y-4">
          <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
            Pollutant Levels
          </h4>
          
          <div className="space-y-3">
            {station.iaqi.pm25 && (
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                  <span className="font-medium">PM2.5</span>
                </div>
                <span className="font-semibold">{station.iaqi.pm25.v} μg/m³</span>
              </div>
            )}
            
            {station.iaqi.pm10 && (
              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                  <span className="font-medium">PM10</span>
                </div>
                <span className="font-semibold">{station.iaqi.pm10.v} μg/m³</span>
              </div>
            )}
          </div>
        </div>

        {/* Last Update */}
        <div className="pt-4 border-t border-border/50">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>Last updated: {new Date(station.time.iso).toLocaleString()}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
