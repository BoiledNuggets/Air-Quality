"use client"

import { useState, useEffect } from "react"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LoadingSpinner } from "./ui/loading-spinner"
import { TrendingUp, AlertCircle } from 'lucide-react'

interface ForecastChartProps {
  stationId: string
  stationName: string
}

interface ForecastData {
  day: string
  value: number
  max: number
  min: number
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white dark:bg-gray-900 p-3 rounded-lg shadow-xl border border-border/50 backdrop-blur-sm">
        <p className="font-semibold mb-2 text-sm">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center gap-2 text-xs">
            <div 
              className="w-2 h-2 rounded-full" 
              style={{ backgroundColor: entry.color }}
            />
            <span className="capitalize">{entry.dataKey}:</span>
            <span className="font-semibold">{entry.value}</span>
            <span className="text-muted-foreground">μg/m³</span>
          </div>
        ))}
      </div>
    )
  }
  return null
}

export default function ForecastChart({ stationId, stationName }: ForecastChartProps) {
  const [forecastData, setForecastData] = useState<ForecastData[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [selectedPollutant, setSelectedPollutant] = useState<"pm25" | "pm10" | "uvi">("pm25")

  useEffect(() => {
    const fetchForecast = async () => {
      if (!stationId) return

      setLoading(true)
      setError(null)

      try {
        const response = await fetch(`/api/forecast/${stationId}`)
        if (!response.ok) {
          throw new Error("Failed to fetch forecast data")
        }

        const data = await response.json()

        if (data.forecast && data.forecast.daily && data.forecast.daily[selectedPollutant]) {
          const formattedData = data.forecast.daily[selectedPollutant].map((item: any) => ({
            day: new Date(item.day).toLocaleDateString("en-US", {
              weekday: "short",
              day: "numeric",
            }),
            value: item.avg,
            max: item.max,
            min: item.min,
          }))
          
          setForecastData(formattedData)
        } else {
          setForecastData([])
        }
      } catch (err) {
        setError("Unable to load forecast data")
        setForecastData([])
      } finally {
        setLoading(false)
      }
    }

    fetchForecast()
  }, [stationId, selectedPollutant])

  const cleanStationName = (name: string) => name.split(",")[0].trim()

  if (loading) {
    return (
      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="flex flex-col items-center justify-center h-48 space-y-3">
            <LoadingSpinner size="md" />
            <div className="text-center space-y-1">
              <p className="font-medium text-sm">Loading forecast...</p>
              <p className="text-xs text-muted-foreground">Analyzing trends</p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error || forecastData.length === 0) {
    return (
      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="flex flex-col items-center justify-center h-48 space-y-3">
            <div className="p-3 bg-orange-100 dark:bg-orange-900/20 rounded-full">
              <AlertCircle className="w-6 h-6 text-orange-600" />
            </div>
            <div className="text-center space-y-1">
              <p className="font-medium text-sm">{error || "No forecast data"}</p>
              <p className="text-xs text-muted-foreground">
                Try a different station
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="glass-card animate-fade-in">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="w-4 h-4 text-primary" />
              7-Day Forecast
            </CardTitle>
            <p className="text-xs text-muted-foreground">
              {cleanStationName(stationName)} • {forecastData.length} days
            </p>
          </div>
          
          <Tabs value={selectedPollutant} onValueChange={(value) => setSelectedPollutant(value as any)}>
            <TabsList className="grid w-full grid-cols-3 h-8">
              <TabsTrigger value="pm25" className="text-xs px-2">PM2.5</TabsTrigger>
              <TabsTrigger value="pm10" className="text-xs px-2">PM10</TabsTrigger>
              <TabsTrigger value="uvi" className="text-xs px-2">UVI</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4 pb-4">
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={forecastData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
              <XAxis 
                dataKey="day" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={10}
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={10}
                tickLine={false}
                axisLine={false}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend 
                wrapperStyle={{ paddingTop: '10px', fontSize: '11px' }}
                iconType="circle"
              />
              
              <Line
                type="monotone"
                dataKey="value"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                dot={{ fill: "hsl(var(--primary))", strokeWidth: 2, r: 3 }}
                activeDot={{ r: 5, stroke: "hsl(var(--primary))", strokeWidth: 2 }}
                name="Average"
              />
              
              <Line 
                type="monotone" 
                dataKey="max" 
                stroke="hsl(var(--destructive))" 
                strokeWidth={1.5} 
                strokeDasharray="4 4" 
                dot={{ fill: "hsl(var(--destructive))", strokeWidth: 1, r: 2 }}
                name="Maximum"
              />
              
              <Line 
                type="monotone" 
                dataKey="min" 
                stroke="hsl(var(--chart-2))" 
                strokeWidth={1.5} 
                strokeDasharray="4 4" 
                dot={{ fill: "hsl(var(--chart-2))", strokeWidth: 1, r: 2 }}
                name="Minimum"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="flex justify-center">
          <div className="inline-flex items-center gap-4 text-xs text-muted-foreground bg-muted/50 px-3 py-1.5 rounded-full">
            <div className="flex items-center gap-1">
              <div className="w-2 h-0.5 bg-primary rounded-full"></div>
              <span>Average</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-0.5 bg-destructive rounded-full opacity-60"></div>
              <span>Range</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
