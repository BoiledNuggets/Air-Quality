"use client"

import { Activity, MapPin, TrendingUp, Users } from 'lucide-react'
import { StatCard } from "./ui/stat-card"
import { ThemeToggle } from "./theme-toggle"

interface HeaderProps {
  stats: {
    total: number
    good: number
    moderate: number
    unhealthy: number
    average: number
  }
}

export function Header({ stats }: HeaderProps) {
  return (
    <div className="space-y-8 animate-slide-up">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-2xl gradient-bg p-8 text-white">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="relative z-10 flex items-center justify-between">
          <div className="space-y-4">
            <div className="space-y-2">
              <h1 className="text-4xl font-bold tracking-tight">
                Thailand Air Quality Monitor
              </h1>
              <p className="text-lg text-white/90 max-w-2xl">
                Real-time air quality monitoring across Thailand with advanced analytics and forecasting
              </p>
              <div className="flex items-center gap-2 text-sm text-white/80">
                <span className="px-2 py-1 bg-white/20 rounded-full">TAMS Project</span>
                <span>•</span>
                <span>Mahanakorn University of Technology</span>
                <span>•</span>
                <span>Powered by AQICN</span>
              </div>
            </div>
          </div>
          <div className="hidden lg:block">
            <ThemeToggle />
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Stations"
          value={stats.total}
          icon={<MapPin className="w-6 h-6" />}
          trend={{ value: 12, isPositive: true }}
        />
        <StatCard
          title="Average AQI"
          value={stats.average}
          icon={<Activity className="w-6 h-6" />}
          trend={{ value: 5, isPositive: false }}
        />
        <StatCard
          title="Good Quality"
          value={stats.good}
          icon={<TrendingUp className="w-6 h-6" />}
          trend={{ value: 8, isPositive: true }}
        />
        <StatCard
          title="Monitoring"
          value={`${stats.moderate + stats.unhealthy}`}
          icon={<Users className="w-6 h-6" />}
          trend={{ value: 3, isPositive: false }}
        />
      </div>
    </div>
  )
}
