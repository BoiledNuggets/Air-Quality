"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Search, MapPin, X } from "lucide-react"

interface StationData {
  aqi: number
  stationId: string
  stationName: string
  coordinates: [number, number]
}

interface LocationSearchProps {
  stations: StationData[]
  onLocationSelect: (station: StationData) => void
  onMapCenter: (coordinates: [number, number]) => void
}

interface SearchResult {
  display_name: string
  lat: string
  lon: string
  type: string
}

export default function LocationSearch({ stations, onLocationSelect, onMapCenter }: LocationSearchProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<SearchResult[]>([])
  const [isSearching, setIsSearching] = useState(false)
  const [showResults, setShowResults] = useState(false)

  const searchLocation = async (query: string) => {
    if (!query.trim()) {
      setSearchResults([])
      setShowResults(false)
      return
    }

    setIsSearching(true)
    try {
      // Search in stations first
      const stationMatches = stations.filter((station) =>
        station.stationName.toLowerCase().includes(query.toLowerCase()),
      )

      // Search using Nominatim API for general locations
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5&countrycodes=th`,
      )
      const locationResults = await response.json()

      // Combine station matches with location results
      const combinedResults = [
        ...stationMatches.map((station) => ({
          display_name: `${station.stationName} (AQI Station)`,
          lat: station.coordinates[0].toString(),
          lon: station.coordinates[1].toString(),
          type: "station",
          station,
        })),
        ...locationResults.map((result: SearchResult) => ({
          ...result,
          type: "location",
        })),
      ]

      setSearchResults(combinedResults)
      setShowResults(true)
    } catch (error) {
      console.error("Search error:", error)
    } finally {
      setIsSearching(false)
    }
  }

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      searchLocation(searchQuery)
    }, 300)

    return () => clearTimeout(timeoutId)
  }, [searchQuery, stations])

  const handleResultClick = (result: any) => {
    const coordinates: [number, number] = [Number.parseFloat(result.lat), Number.parseFloat(result.lon)]

    if (result.type === "station" && result.station) {
      onLocationSelect(result.station)
    } else {
      // Find nearest station for general locations
      const nearestStation = findNearestStation(coordinates)
      if (nearestStation) {
        onLocationSelect(nearestStation)
      }
    }

    onMapCenter(coordinates)
    setShowResults(false)
    setSearchQuery("")
  }

  const findNearestStation = (coordinates: [number, number]) => {
    let nearest = null
    let minDistance = Number.POSITIVE_INFINITY

    stations.forEach((station) => {
      const distance = calculateDistance(coordinates, station.coordinates)
      if (distance < minDistance) {
        minDistance = distance
        nearest = station
      }
    })

    return nearest
  }

  const calculateDistance = (coord1: [number, number], coord2: [number, number]) => {
    const [lat1, lon1] = coord1
    const [lat2, lon2] = coord2
    const R = 6371 // Earth's radius in km
    const dLat = ((lat2 - lat1) * Math.PI) / 180
    const dLon = ((lon2 - lon1) * Math.PI) / 180
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  }

  return (
    <div className="relative">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input
          type="text"
          placeholder="Search for a location or station..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-10 pr-10"
        />
        {searchQuery && (
          <Button
            variant="ghost"
            size="sm"
            className="absolute right-1 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0"
            onClick={() => {
              setSearchQuery("")
              setShowResults(false)
            }}
          >
            <X className="h-3 w-3" />
          </Button>
        )}
      </div>

      {showResults && searchResults.length > 0 && (
        <Card className="absolute top-full left-0 right-0 z-[1001] mt-1 max-h-60 overflow-y-auto shadow-lg border">
          <CardContent className="p-0">
            {searchResults.map((result, index) => (
              <div
                key={index}
                className="flex items-center gap-3 p-3 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer border-b last:border-b-0"
                onClick={() => handleResultClick(result)}
              >
                <MapPin className="h-4 w-4 text-gray-400 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{result.display_name}</p>
                  {result.type === "station" && (
                    <p className="text-xs text-blue-600 dark:text-blue-400">AQI Monitoring Station</p>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {isSearching && (
        <div className="absolute top-full left-0 right-0 z-[1001] mt-1 shadow-lg">
          <Card>
            <CardContent className="p-3 text-center text-sm text-gray-500">Searching...</CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
