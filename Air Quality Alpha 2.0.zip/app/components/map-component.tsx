"use client"

import { useEffect, useRef, useState } from "react"
import * as L from "leaflet"
import "leaflet/dist/leaflet.css"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MapPin, Layers, X } from 'lucide-react'

// Fix for default markers in Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "/placeholder.svg?height=25&width=25",
  iconUrl: "/placeholder.svg?height=25&width=25",
  shadowUrl: "/placeholder.svg?height=25&width=25",
})

interface StationData {
  aqi: number
  dominentpol: string
  city: {
    name: string
    geo: [number, number]
  }
  time: {
    iso: string
  }
  iaqi: {
    pm25?: { v: number }
    pm10?: { v: number }
    o3?: { v: number }
    t?: { v: number }
    h?: { v: number }
    w?: { v: number }
    wd?: { v: number }
  }
  stationId: string
  stationName: string
  coordinates: [number, number]
}

interface MapComponentProps {
  stationsData: StationData[]
  selectedStation: StationData | null
  onStationSelect: (station: StationData) => void
  mapLayer: "street" | "satellite" | "hybrid"
  onLayerChange: (layer: "street" | "satellite" | "hybrid") => void
  mapCenter?: [number, number]
}

interface MapClickInfo {
  lat: number
  lng: number
  visible: boolean
}

const getAQIColor = (aqi: number) => {
  if (aqi <= 50) return "#10b981"
  if (aqi <= 100) return "#f59e0b"
  if (aqi <= 150) return "#f97316"
  if (aqi <= 200) return "#ef4444"
  if (aqi <= 300) return "#a855f7"
  return "#7f1d1d"
}

const getAQIStatus = (aqi: number) => {
  if (aqi <= 50) return "Good"
  if (aqi <= 100) return "Moderate"
  if (aqi <= 150) return "Unhealthy for Sensitive Groups"
  if (aqi <= 200) return "Unhealthy"
  if (aqi <= 300) return "Very Unhealthy"
  return "Hazardous"
}

const getWindDirection = (degrees: number) => {
  const directions = ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW']
  const index = Math.round(degrees / 22.5) % 16
  return directions[index]
}

const getWindArrow = (degrees: number) => {
  return `<div style="transform: rotate(${degrees}deg); display: inline-block; font-size: 16px; color: #3b82f6;">↑</div>`
}

export default function MapComponent({
  stationsData,
  selectedStation,
  onStationSelect,
  mapLayer,
  onLayerChange,
  mapCenter,
}: MapComponentProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<L.Map | null>(null)
  const markersRef = useRef<L.CircleMarker[]>([])
  const currentLayerRef = useRef<L.TileLayer | null>(null)
  const [mapClickInfo, setMapClickInfo] = useState<MapClickInfo>({ lat: 0, lng: 0, visible: false })

  useEffect(() => {
    if (!mapRef.current) return

    const map = L.map(mapRef.current, {
      zoomControl: false,
      attributionControl: false,
      doubleClickZoom: false,
      boxZoom: false,
    }).setView([13.0, 101.0], 6)
    
    mapInstanceRef.current = map

    // Add zoom control to top right
    L.control.zoom({ position: 'topright' }).addTo(map)

    const streetLayer = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap contributors",
    })
    streetLayer.addTo(map)
    currentLayerRef.current = streetLayer

    // Add click handler for empty map areas
    map.on('click', (e) => {
      const clickedElement = e.originalEvent.target as HTMLElement
      if (!clickedElement.closest('.leaflet-marker-icon') && !clickedElement.closest('.leaflet-interactive')) {
        setMapClickInfo({
          lat: e.latlng.lat,
          lng: e.latlng.lng,
          visible: true
        })
      }
    })

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
    }
  }, [])

  useEffect(() => {
    if (mapInstanceRef.current && mapCenter) {
      mapInstanceRef.current.setView(mapCenter, 12)
    }
  }, [mapCenter])

  useEffect(() => {
    if (!mapInstanceRef.current) return

    if (currentLayerRef.current) {
      mapInstanceRef.current.removeLayer(currentLayerRef.current)
    }

    let newLayer: L.TileLayer

    switch (mapLayer) {
      case "satellite":
        newLayer = L.tileLayer(
          "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
          { attribution: "© Esri" }
        )
        break
      case "hybrid":
        newLayer = L.tileLayer(
          "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
          { attribution: "© Esri" }
        )
        const labelsLayer = L.tileLayer(
          "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}",
          { attribution: "" }
        )
        newLayer.addTo(mapInstanceRef.current)
        labelsLayer.addTo(mapInstanceRef.current)
        currentLayerRef.current = newLayer
        return
      default:
        newLayer = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: "© OpenStreetMap contributors",
        })
    }

    newLayer.addTo(mapInstanceRef.current)
    currentLayerRef.current = newLayer
  }, [mapLayer])

  useEffect(() => {
    if (!mapInstanceRef.current || !stationsData.length) return

    markersRef.current.forEach((marker) => {
      mapInstanceRef.current?.removeLayer(marker)
    })
    markersRef.current = []

    const bounds = L.latLngBounds([])

    stationsData.forEach((station) => {
      const [lat, lng] = station.coordinates
      bounds.extend([lat, lng])

      const baseRadius = 8
      const radius = selectedStation?.stationId === station.stationId ? baseRadius + 6 : baseRadius
      const isRedStation = station.aqi > 200 // Red stations (Unhealthy and above)

      const marker = L.circleMarker([lat, lng], {
        radius: radius,
        fillColor: getAQIColor(station.aqi),
        color: selectedStation?.stationId === station.stationId ? "#1f2937" : "#ffffff",
        weight: selectedStation?.stationId === station.stationId ? 4 : 2,
        opacity: 1,
        fillOpacity: 0.9,
        className: isRedStation ? 'blinking-marker' : ''
      })

      // Add blinking animation for red stations
      if (isRedStation) {
        const blinkInterval = setInterval(() => {
          const currentOpacity = marker.options.fillOpacity
          marker.setStyle({
            fillOpacity: currentOpacity === 0.9 ? 0.3 : 0.9
          })
        }, 800) // Blink every 800ms

        // Store interval reference to clean up later
        ;(marker as any)._blinkInterval = blinkInterval
      }

      const cleanStationName = station.stationName.split(",")[0]
      const popupContent = `
  <div class="p-4 min-w-[280px] space-y-4 bg-white dark:bg-gray-900 rounded-lg">
    <div class="space-y-3">
      <div class="flex items-start justify-between">
        <h3 class="font-bold text-lg text-gray-900 dark:text-white leading-tight pr-2">${cleanStationName}</h3>
        <div class="px-3 py-1.5 rounded-full text-white font-semibold text-sm whitespace-nowrap" style="background-color: ${getAQIColor(station.aqi)}; box-shadow: 0 2px 8px ${getAQIColor(station.aqi)}40;">
          AQI ${station.aqi}
        </div>
      </div>
      <div class="text-sm font-medium text-gray-600 dark:text-gray-300 bg-gray-50 dark:bg-gray-800 px-3 py-1.5 rounded-full inline-block">
        ${getAQIStatus(station.aqi)}
      </div>
    </div>
    
    <div class="grid grid-cols-2 gap-3 text-sm">
      ${station.iaqi.pm25 ? `
        <div class="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 p-3 rounded-lg border border-orange-200 dark:border-orange-800">
          <div class="text-orange-600 dark:text-orange-400 text-xs font-medium uppercase tracking-wide">PM2.5</div>
          <div class="font-bold text-lg text-orange-800 dark:text-orange-200">${station.iaqi.pm25.v}</div>
          <div class="text-orange-600 dark:text-orange-400 text-xs">μg/m³</div>
        </div>
      ` : ''}
      ${station.iaqi.t ? `
        <div class="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-800/20 p-3 rounded-lg border border-red-200 dark:border-red-800">
          <div class="text-red-600 dark:text-red-400 text-xs font-medium uppercase tracking-wide">Temperature</div>
          <div class="font-bold text-lg text-red-800 dark:text-red-200">${station.iaqi.t.v}°</div>
          <div class="text-red-600 dark:text-red-400 text-xs">Celsius</div>
        </div>
      ` : ''}
      ${station.iaqi.h ? `
        <div class="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 p-3 rounded-lg border border-blue-200 dark:border-blue-800">
          <div class="text-blue-600 dark:text-blue-400 text-xs font-medium uppercase tracking-wide">Humidity</div>
          <div class="font-bold text-lg text-blue-800 dark:text-blue-200">${station.iaqi.h.v}%</div>
          <div class="text-blue-600 dark:text-blue-400 text-xs">Relative</div>
        </div>
      ` : ''}
      ${station.iaqi.w ? `
        <div class="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800/50 dark:to-gray-700/50 p-3 rounded-lg border border-gray-200 dark:border-gray-700 ${station.iaqi.h ? '' : 'col-span-2'}">
          <div class="text-gray-600 dark:text-gray-400 text-xs font-medium uppercase tracking-wide">Wind</div>
          <div class="flex items-center gap-2 mt-1">
            <span class="font-bold text-lg text-gray-800 dark:text-gray-200">${station.iaqi.w.v}</span>
            <span class="text-gray-600 dark:text-gray-400 text-xs">km/h</span>
            ${station.iaqi.wd ? getWindArrow(station.iaqi.wd.v) : ''}
            ${station.iaqi.wd ? `<span class="text-xs font-medium text-gray-600 dark:text-gray-400">${getWindDirection(station.iaqi.wd.v)}</span>` : ''}
          </div>
        </div>
      ` : ''}
    </div>
    
    <div class="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 pt-3 border-t border-gray-200 dark:border-gray-700">
      <div class="flex items-center gap-1">
        <div class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
        <span>Live Data</span>
      </div>
      <span>Updated: ${new Date(station.time.iso).toLocaleTimeString()}</span>
    </div>
  </div>
`

      marker.bindPopup(popupContent, {
        maxWidth: 320,
        minWidth: 280,
        className: "custom-popup",
        closeButton: true,
        autoClose: false,
        closeOnClick: false,
        closeOnEscapeKey: true,
        keepInView: true,
        autoPan: false, // Disable auto-pan to prevent zoom issues
        autoPanPadding: [20, 20]
      })
      marker.addTo(mapInstanceRef.current!)
      markersRef.current.push(marker)

      marker.on("click", (e) => {
        // Prevent all default behaviors
        L.DomEvent.stopPropagation(e)
        L.DomEvent.preventDefault(e)
        
        // Store current map state before any operations
        const currentZoom = mapInstanceRef.current!.getZoom()
        const currentCenter = mapInstanceRef.current!.getCenter()
        
        // Select the station first
        onStationSelect(station)
        
        // Open popup immediately and restore map state
        marker.openPopup()
        
        // Force map to stay at current position
        mapInstanceRef.current!.setView(currentCenter, currentZoom, { animate: false })
        
        // Hide map click popup
        setMapClickInfo({ lat: 0, lng: 0, visible: false })
        
        // Additional safeguard - prevent any zoom changes for a short period
        const originalSetView = mapInstanceRef.current!.setView
        mapInstanceRef.current!.setView = function(center, zoom, options) {
          // Only allow the restoration call we made above
          if (zoom === currentZoom && center.equals(currentCenter)) {
            return originalSetView.call(this, center, zoom, options)
          }
          return this
        }
        
        // Restore normal setView after a brief delay
        setTimeout(() => {
          if (mapInstanceRef.current) {
            mapInstanceRef.current.setView = originalSetView
          }
        }, 100)
      })

      // Clean up interval when marker is removed
      marker.on("remove", () => {
        if ((marker as any)._blinkInterval) {
          clearInterval((marker as any)._blinkInterval)
        }
      })
    })

    if (bounds.isValid() && !mapCenter) {
      mapInstanceRef.current.fitBounds(bounds, { padding: [20, 20] })
    }

    // Cleanup function to clear all intervals
    return () => {
      markersRef.current.forEach((marker) => {
        if ((marker as any)._blinkInterval) {
          clearInterval((marker as any)._blinkInterval)
        }
      })
    }
  }, [stationsData, selectedStation, onStationSelect, mapCenter])

  return (
    <div className="relative">
      <Card className="glass-card animate-fade-in overflow-hidden">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-primary" />
              Interactive Map
              <span className="text-sm font-normal text-muted-foreground">
                ({stationsData.length} stations)
              </span>
            </CardTitle>
            
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-muted-foreground" />
              <div className="flex gap-1">
                <Button
                  variant={mapLayer === "street" ? "default" : "outline"}
                  size="sm"
                  onClick={() => onLayerChange("street")}
                  className="text-xs px-3"
                >
                  Street
                </Button>
                <Button
                  variant={mapLayer === "satellite" ? "default" : "outline"}
                  size="sm"
                  onClick={() => onLayerChange("satellite")}
                  className="text-xs px-3"
                >
                  Satellite
                </Button>
                <Button
                  variant={mapLayer === "hybrid" ? "default" : "outline"}
                  size="sm"
                  onClick={() => onLayerChange("hybrid")}
                  className="text-xs px-3"
                >
                  Hybrid
                </Button>
              </div>
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="p-0">
          <div ref={mapRef} className="w-full h-[500px] relative z-0" />
        </CardContent>
      </Card>

      {/* Map Click Info Popup */}
      {mapClickInfo.visible && (
        <div 
          className="absolute z-[1000] bg-white dark:bg-gray-900 rounded-lg shadow-xl border border-border/50 p-4 min-w-[200px] animate-fade-in"
          style={{
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            pointerEvents: 'auto'
          }}
        >
          <div className="flex items-start justify-between mb-3">
            <h4 className="font-semibold text-sm">Location Info</h4>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 hover:bg-muted"
              onClick={() => setMapClickInfo({ lat: 0, lng: 0, visible: false })}
            >
              <X className="h-3 w-3" />
            </Button>
          </div>
          
          <div className="space-y-2 text-xs text-muted-foreground">
            <div className="flex justify-between">
              <span>Latitude:</span>
              <span className="font-mono">{mapClickInfo.lat.toFixed(6)}</span>
            </div>
            <div className="flex justify-between">
              <span>Longitude:</span>
              <span className="font-mono">{mapClickInfo.lng.toFixed(6)}</span>
            </div>
            <div className="pt-2 border-t border-border/50">
              <p className="text-xs text-muted-foreground">
                Click on a station marker to view air quality data
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
