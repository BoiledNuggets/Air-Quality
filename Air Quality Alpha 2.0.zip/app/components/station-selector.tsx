"use client"

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AQIBadge } from "./ui/aqi-badge"
import { MapPin, Search } from 'lucide-react'
import { Card, CardContent } from "@/components/ui/card"

interface StationData {
  aqi: number
  dominentpol: string
  stationId: string
  stationName: string
  coordinates: [number, number]
}

interface StationSelectorProps {
  stations: StationData[]
  selectedStation: StationData | null
  onStationSelect: (station: StationData) => void
}

const cleanStationName = (name: string) => {
  const cleaned = name.split(",")[0].trim()
  return cleaned.length > 50 ? cleaned.substring(0, 50) + "..." : cleaned
}

export default function StationSelector({ stations, selectedStation, onStationSelect }: StationSelectorProps) {
  const sortedStations = [...stations].sort((a, b) => {
    if (b.aqi !== a.aqi) return b.aqi - a.aqi
    return cleanStationName(a.stationName).localeCompare(cleanStationName(b.stationName))
  })

  return (
    <Card className="glass-card animate-fade-in">
      <CardContent className="p-6">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Search className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold">Select Monitoring Station</h3>
              <p className="text-sm text-muted-foreground">
                Choose from {stations.length} active stations across Thailand
              </p>
            </div>
          </div>
          
          <Select
            value={selectedStation?.stationId || ""}
            onValueChange={(value) => {
              const station = stations.find((s) => s.stationId === value)
              if (station) onStationSelect(station)
            }}
          >
            <SelectTrigger className="w-full h-12 focus-ring">
              <SelectValue placeholder="Choose a monitoring station..." />
            </SelectTrigger>
            <SelectContent className="max-h-80">
              {sortedStations.map((station) => (
                <SelectItem key={station.stationId} value={station.stationId} className="py-3">
                  <div className="flex items-center justify-between w-full min-w-0">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <MapPin className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      <span className="truncate" title={station.stationName}>
                        {cleanStationName(station.stationName)}
                      </span>
                    </div>
                    <AQIBadge aqi={station.aqi} size="sm" />
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardContent>
    </Card>
  )
}
