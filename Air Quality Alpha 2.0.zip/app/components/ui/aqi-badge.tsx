import { cn } from "@/lib/utils"

interface AQIBadgeProps {
  aqi: number
  size?: "sm" | "md" | "lg"
  showStatus?: boolean
  className?: string
}

const getAQIColor = (aqi: number) => {
  if (aqi <= 50) return "bg-green-500 text-white shadow-green-500/30"
  if (aqi <= 100) return "bg-yellow-500 text-white shadow-yellow-500/30"
  if (aqi <= 150) return "bg-orange-500 text-white shadow-orange-500/30"
  if (aqi <= 200) return "bg-red-500 text-white shadow-red-500/30"
  if (aqi <= 300) return "bg-purple-500 text-white shadow-purple-500/30"
  return "bg-red-900 text-white shadow-red-900/30"
}

const getAQIStatus = (aqi: number) => {
  if (aqi <= 50) return "Good"
  if (aqi <= 100) return "Moderate"
  if (aqi <= 150) return "Unhealthy for Sensitive"
  if (aqi <= 200) return "Unhealthy"
  if (aqi <= 300) return "Very Unhealthy"
  return "Hazardous"
}

export function AQIBadge({ aqi, size = "md", showStatus = false, className }: AQIBadgeProps) {
  const sizeClasses = {
    sm: "text-xs px-2 py-1",
    md: "text-sm px-3 py-1.5",
    lg: "text-lg px-4 py-2"
  }

  return (
    <div className={cn(
      "inline-flex items-center gap-2 rounded-full font-semibold shadow-lg transition-all duration-200",
      getAQIColor(aqi),
      sizeClasses[size],
      className
    )}>
      <span>{aqi}</span>
      {showStatus && <span className="text-xs opacity-90">{getAQIStatus(aqi)}</span>}
    </div>
  )
}
