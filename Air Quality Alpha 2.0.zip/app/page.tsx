"use client"

import { useState, useEffect } from "react"
import dynamic from "next/dynamic"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertTriangle } from 'lucide-react'
import { Header } from "./components/header"
import StationSelector from "./components/station-selector"
import { CurrentConditions } from "./components/current-conditions"
import ForecastChart from "./components/forecast-chart"
import { LoadingSpinner } from "./components/ui/loading-spinner"

const MapComponent = dynamic(() => import("./components/map-component"), {
  ssr: false,
  loading: () => (
    <div className="glass-card animate-pulse">
      <div className="h-[500px] bg-muted/50 rounded-xl flex items-center justify-center">
        <div className="text-center space-y-4">
          <LoadingSpinner size="lg" />
          <p className="text-muted-foreground">Loading interactive map...</p>
        </div>
      </div>
    </div>
  ),
})

interface StationData {
  aqi: number
  dominentpol: string
  city: {
    name: string
    geo: [number, number]
  }
  time: {
    iso: string
  }
  iaqi: {
    pm25?: { v: number }
    pm10?: { v: number }
    o3?: { v: number }
    t?: { v: number }
    h?: { v: number }
    w?: { v: number }
    wd?: { v: number }
  }
  forecast: {
    daily: {
      pm25?: Array<{ avg: number; day: string; max: number; min: number }>
      pm10?: Array<{ avg: number; day: string; max: number; min: number }>
      o3?: Array<{ avg: number; day: string; max: number; min: number }>
      uvi?: Array<{ avg: number; day: string; max: number; min: number }>
    }
  }
  stationId: string
  stationName: string
  coordinates: [number, number]
}

const getAQIStatus = (aqi: number) => {
  if (aqi <= 50) return "Good"
  if (aqi <= 100) return "Moderate"
  if (aqi <= 150) return "Unhealthy for Sensitive Groups"
  if (aqi <= 200) return "Unhealthy"
  if (aqi <= 300) return "Very Unhealthy"
  return "Hazardous"
}

const cleanStationName = (name: string) => name.split(",")[0].trim()

export default function BangkokAirQuality() {
  const [stationsData, setStationsData] = useState<StationData[]>([])
  const [selectedStation, setSelectedStation] = useState<StationData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [mapLayer, setMapLayer] = useState<"street" | "satellite" | "hybrid">("street")
  const [mapCenter, setMapCenter] = useState<[number, number] | undefined>(undefined)

  useEffect(() => {
    const fetchAQIData = async () => {
      try {
        setLoading(true)
        const response = await fetch("/api/aqi-data")
        if (!response.ok) {
          throw new Error("Failed to fetch AQI data")
        }
        const data = await response.json()
        setStationsData(data.stations)
        
        if (data.stations.length > 0) {
          const sortedByAQI = [...data.stations].sort((a, b) => b.aqi - a.aqi)
          setSelectedStation(sortedByAQI[0])
        }
        setError(null)
      } catch (err) {
        setError("Failed to load air quality data. Please try again later.")
        console.error("Error fetching AQI data:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchAQIData()
    const interval = setInterval(fetchAQIData, 10 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  const stats = {
    total: stationsData.length,
    good: stationsData.filter((s) => s.aqi <= 50).length,
    moderate: stationsData.filter((s) => s.aqi > 50 && s.aqi <= 100).length,
    unhealthy: stationsData.filter((s) => s.aqi > 100).length,
    average:
      stationsData.length > 0 ? Math.round(stationsData.reduce((sum, s) => sum + s.aqi, 0) / stationsData.length) : 0,
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
        <div className="container mx-auto px-4 py-8">
          <div className="space-y-8">
            <div className="loading-shimmer h-32 rounded-2xl"></div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="loading-shimmer h-24 rounded-xl"></div>
              ))}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 loading-shimmer h-96 rounded-xl"></div>
              <div className="loading-shimmer h-96 rounded-xl"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="container mx-auto px-4 py-8 space-y-8">
        <Header stats={stats} />

        {/* Critical Air Quality Alert */}
        {selectedStation && selectedStation.aqi > 150 && (
          <Alert className="border-destructive/50 bg-destructive/10 animate-fade-in">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            <AlertDescription className="text-destructive font-medium">
              <strong>Air Quality Alert:</strong> Unhealthy conditions detected at{" "}
              {cleanStationName(selectedStation.stationName)} (AQI: {selectedStation.aqi} - {getAQIStatus(selectedStation.aqi)}).
              Consider limiting outdoor activities.
            </AlertDescription>
          </Alert>
        )}

        {error && (
          <Alert className="border-destructive/50 bg-destructive/10 animate-fade-in">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            <AlertDescription className="text-destructive">{error}</AlertDescription>
          </Alert>
        )}

        {/* Station Selection */}
        {stationsData.length > 0 && (
          <StationSelector
            stations={stationsData}
            selectedStation={selectedStation}
            onStationSelect={setSelectedStation}
          />
        )}

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Map Section */}
          <div className="lg:col-span-2">
            <MapComponent
              stationsData={stationsData}
              selectedStation={selectedStation}
              onStationSelect={setSelectedStation}
              mapLayer={mapLayer}
              onLayerChange={setMapLayer}
              mapCenter={mapCenter}
            />
          </div>

          {/* Current Conditions */}
          <div>
            {selectedStation && <CurrentConditions station={selectedStation} />}
          </div>
        </div>

        {/* Forecast Section */}
        {selectedStation && (
          <ForecastChart 
            stationId={selectedStation.stationId} 
            stationName={selectedStation.stationName}
          />
        )}

        {/* Footer */}
        <div className="text-center py-8 border-t border-border/50">
          <p className="text-sm text-muted-foreground">
            © 2025 Thailand Air Quality Monitor • TAMS Project • Mahanakorn University of Technology
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            Data provided by World Air Quality Index Project • Updated every 10 minutes
          </p>
        </div>
      </div>
    </div>
  )
}
